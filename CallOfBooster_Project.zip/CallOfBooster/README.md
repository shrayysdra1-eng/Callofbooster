# Call of Booster

Android Studio project for package `com.sahandytsupport.callofbooster`.

## Build
Open this directory in Android Studio (JDK 17; Android SDK 35) and sync Gradle. The Shizuku API dependency is resolved by Gradle from Maven Central.

## Use
Install and start Shizuku separately, connect from this app, then optionally run Android GameManager's `performance` mode for `com.activision.callofduty.shooter`. Availability depends on Android version/device ROM. The app also has a regular game-launch button. It does not modify game files, automate gameplay, or promise FPS improvements. Revert the mode with Android's standard/battery GameManager mode or the device's game settings if supported.
