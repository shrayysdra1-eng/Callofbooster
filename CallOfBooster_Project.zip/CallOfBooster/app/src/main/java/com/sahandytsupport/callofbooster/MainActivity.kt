package com.sahandytsupport.callofbooster

import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors

class MainActivity : android.app.Activity() {
    private val requestCode = 4201
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var output: TextView
    private val gamePackage = "com.activision.callofduty.shooter"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.shizukuStatus)
        output = findViewById(R.id.outputText)
        findViewById<Button>(R.id.permissionButton).setOnClickListener { requestShizukuPermission() }
        findViewById<Button>(R.id.launchButton).setOnClickListener { launchGame() }
        findViewById<Button>(R.id.performanceButton).setOnClickListener {
            runShizukuCommand("cmd game mode performance $gamePackage")
        }
        refreshStatus()
    }

    private fun refreshStatus() {
        val running = Shizuku.pingBinder()
        status.text = when {
            !running -> "Shizuku is not running. Start Shizuku, then reconnect."
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> "Shizuku connected · permission granted"
            else -> "Shizuku connected · permission not granted"
        }
    }

    private fun requestShizukuPermission() {
        if (!Shizuku.pingBinder()) {
            output.text = "Shizuku is not running. Open the Shizuku app and start its service first."
            refreshStatus()
            return
        }
        if (Shizuku.isPreV11()) {
            output.text = "Please update Shizuku to a supported version."
            return
        }
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            output.text = "Shizuku permission is already granted."
            refreshStatus()
        } else {
            Shizuku.requestPermission(requestCode)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode) {
            output.text = if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                "Shizuku permission granted. You can run supported ADB actions."
            else "Shizuku permission was denied."
            refreshStatus()
        }
    }

    private fun launchGame() {
        try {
            val intent = packageManager.getLaunchIntentForPackage(gamePackage)
            if (intent == null) {
                output.text = "Call of Duty: Mobile is not installed (or its launcher is unavailable)."
            } else {
                startActivity(intent)
                output.text = "Launching Call of Duty: Mobile."
            }
        } catch (e: ActivityNotFoundException) {
            output.text = "Could not open the game: ${e.message ?: "activity unavailable"}"
        }
    }

    private fun runShizukuCommand(command: String) {
        if (!Shizuku.pingBinder()) {
            output.text = "Shizuku is not running. Start its service first."
            refreshStatus()
            return
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            output.text = "Grant Shizuku permission before running this ADB command."
            requestShizukuPermission()
            return
        }
        output.text = "Running: $command"
        worker.execute {
            val result = try {
                val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
                val stdout = BufferedReader(InputStreamReader(process.inputStream)).readText()
                val stderr = BufferedReader(InputStreamReader(process.errorStream)).readText()
                val code = process.waitFor()
                "Exit code: $code" + listOf(stdout, stderr).filter { it.isNotBlank() }.joinToString("\n")
                    .let { if (it.isBlank()) "\nNo command output." else "\n$it" }
            } catch (e: Exception) {
                "Command failed: ${e.message ?: e.javaClass.simpleName}"
            }
            runOnUiThread {
                output.text = result
                refreshStatus()
            }
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }
}
